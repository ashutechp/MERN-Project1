const userList = [
    {
        id: '624b2033134f61b8552948f6',
        title: 'Frank',
        isbn: 'Frank Degrassi',
        author:'Author 1',
        description:'description',
        published_date:'01/01/2010',
        publisher:'Geetapresh Gorakhpur',
        updated_date:'04/04/2022'
    },
    {
        id: '624b2033134f61b8522933f6',
        title: 'John',
        isbn: 'John Degrassi',
        author:'Author 2',
        description:'description 2',
        published_date:'01/01/2011',
        publisher:'Wiley',
        updated_date:'04/04/2022'
    }
];

export default userList;