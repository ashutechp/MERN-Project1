import { useState, useEffect } from 'react';
import axios from 'axios';

const TodoServer = () => {
	let [todos, setTodos] = useState([{
		name: "read book",
		status: "complete"
	}])
	let [id, setId] = useState(0);

	useEffect(() => {
		callServer();
		console.log("Component loaded");
		const callMeWhenComponentRemoved = function () {
			alert("I'm being removed from the browser");
		};
	}, []);

	const callServer = () => {
		axios.get("todos").then(function (res) {
			console.log(res.data);
			setTodos(res.data)
		});
	};

	const callServerWithId = () => {
		axios.get("todos/" + id).then(function (res) {
			console.log(res.data)

		});
	};
	/*
	const deleteTodo = (indexToDelete) => {
		axios.get("/todos/delete/" + indexToDelete)
			.then((res) => { alert(res.data) })
			.catch((error) => {
				alert(error)
			})
		callServer();
	};
	*/



	const addTodo = (event) => {
		event.preventDefault();
		const todoObject = {
			name: event.target.name.value,
			status: event.target.status.value
		};
		//console.log("React todoObject",todoObject)
		axios.post("/todos", todoObject)
			.then((res) => {
				alert(res)
				callServer()
			}).catch((error) => alert("error", error))

		callServer();
	};



	/*
		const addTodo = (event) => {
			event.preventDefault();
	
			const todoObject = {
				name: event.target.name.value,
				status: event.target.status.value,
			};
			//console.log("todoObject-->", {})
			axios.post("/todos", todoObject)
				.then((res) => {
					console.log("res", res)
					// callServer();
				}).catch((error) => { alert(error) });
	}*/


	const deleteTodo = (_id) => {
		axios.delete("/todos/" + _id).then((res) => {
			console.log(res)
		}).catch((err) => {
			console.log(err);
		});
		callServer();

	};
	return (
		<div>
			<button onClick={callServer}> CallServer </button>
			{
				todos.map((val, index) => {
					return (
						<div>
							Name: {val.name} and status : {String(val.status)}
							<button onClick={() => { deleteTodo(val._id) }}>delete </button>
						</div>
					);
				})}
			<button onClick={callServerWithId}> Get single todo </button>
			<input
				type="number"
				value={id}
				onInput={(event) => setId(event.target.value)} />

			<form onSubmit={addTodo}>
				<input type="text" name="name" placeholder="Enter Todo Name" />
				<select name="status">
					<option value="complete">complete</option>
					<option value="incomplete">incomplete</option>
				</select>
				<button>Add Todo </button>
			</form>

		</div>
	)

}

export default TodoServer;

