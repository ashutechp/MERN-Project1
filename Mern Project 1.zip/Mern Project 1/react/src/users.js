const data = [
    {
        id: 1,
        name: 'sander',
        username: 'sanderdebr'
    },
    {
        id: 2,
        name: 'berend',
        username: 'berend123'
    }
]

export default data;