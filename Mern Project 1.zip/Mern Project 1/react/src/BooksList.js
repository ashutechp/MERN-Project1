import React, { useState } from 'react';


const mydata = { "status": 1, "data": { "books_list": [{ "_id": "624bba5df4de3019001ae213", "title": "Serial", "isbn": "ISBN", "author": "Pizzo", "description": "underworld", "published_date": "1959-12-31T18:30:00.000Z", "publisher": "Penguine", "updated_date": "2022-04-03T18:30:00.000Z", "__v": 0 }, { "_id": "624bc968f4de3019001ae249", "title": "name", "isbn": "job", "author": "Me", "description": "my description", "published_date": "1969-12-31T18:30:00.000Z", "publisher": "Geeta Press", "updated_date": "1969-12-31T18:30:00.000Z", "__v": 0 }, { "_id": "624bcaf0f4de3019001ae24b", "title": "title 4", "isbn": "ISBN", "author": "Rachna", "description": "Thriller", "published_date": "2022-04-07T00:00:00.000Z", "publisher": "Penguine", "updated_date": "2022-04-05T04:52:00.385Z", "__v": 0 }] } }


function BooksList() {
    const [books, updateBooks] = React.useState([]);

    React.useEffect(function effectFunction() {
        updateBooks(mydata.data.books_list)
          
        }, []);

    return (
        <ul>
            {books.map(book => (
                <li key={book._id}>{book.isbn}</li>
            ))};
        </ul>
    );
}

export default BooksList;