import { useState, useEffect } from 'react';
import axios from 'axios';
import { getQueriesForElement } from '@testing-library/react';


const ExpressServer = () => {

	let [books, setBooks] = useState([])
	let [editFlag, setEditFlag] = useState(false)
	let [iid, setIid] = useState('1')

	useEffect(() => {
		callServer();
	}, []);


	const handleSubmit = async (event) => {
		event.preventDefault();
		let newTile = event.target.title.value;
		let newIsbn = event.target.isbn.value;
		let newAuthor = event.target.author.value;
		let newDescription = event.target.description.value;
		let newPublished_date = event.target.published_date.value;
		let newPublisher = event.target.publisher.value;
		let newUpdated_date = event.target.updated_date.value;

		const data = { title: newTile, isbn: newIsbn, author: newAuthor, description: newDescription, published_date: newPublished_date, publisher: newPublisher, updated_date: new Date() };
		axios.post('http://localhost:8082/books', data)
			.then(response => {
				console.log("Status: ", response.status);
				console.log("Data: ", response.data);
			}).catch(error => {
				console.error('Something went wrong!', error);
			});

			callServer();

	}



	const handleSubmitUpdate = async (event) => {
		event.preventDefault()
		let newTile = event.target.title.value;
		let newIsbn = event.target.isbn.value;
		let newAuthor = event.target.author.value;
		let newDescription = event.target.description.value;
		let newPublished_date = event.target.published_date.value;
		let newPublisher = event.target.publisher.value;
		let newUpdated_date = event.target.updated_date.value;
       
		const data = { title: newTile, isbn: newIsbn, author: newAuthor, description: newDescription, published_date: newPublished_date, publisher: newPublisher, updated_date: new Date() };
		console.log("data ID before submitting",iid)
		axios.put("http://localhost:8082/books/" + iid, data

		)
			.then(response => {
				console.log("Status: ", response.status);
				console.log("Data: ", response.data);
			}).catch(error => {
				console.error('Something went wrong!', error);
			});
			callServer();
	}

	const deleteUser = (id) => {
		axios.delete("http://localhost:8082/books/" + id).then((res) => {
			console.log(res)
		}).catch((err) => {
			console.log(err);
		});
		callServer();
	}

  const getFormData=(_id, title, isbn, author, description, published_date, publisher, updated_date)=>{
	console.log("Final ID",_id)
	return (
		<form onSubmit={handleSubmitUpdate}>
			<input type="hidden" name="id"/> <br />
			Title: <input type="text" name="title" value={title}/> <br />
			isbn: <input type="text" name="isbn" value={isbn}/><br />
			author: <input type="text" name="author" /><br />
			description: <input type="text" name="description" /><br />
			published_date: <input type="date" name="published_date" /><br />
			publisher: <input type="text" name="publisher" /><br />
			updated_date:<input type="date" name="updated_date" /><br />
			<button>Edit the record</button><br />
		</form>
		)
  }


	function editUser(_id, title, isbn, author, description, published_date, publisher, updated_date) {
		
		books.map((v,i)=>{
				if(v._id===_id){
					console.log("values matched with",_id);
					setIid(_id);
					getFormData(_id, title, isbn, author, description, published_date, publisher, updated_date)
				}
		})
		
		
	}

	const addUser = () => {
		return (
			<form onSubmit={handleSubmit}>
				Title: <input type="text" name="title" /> <br />
				isbn: <input type="text" name="isbn" /><br />
				author: <input type="text" name="author" /><br />
				description: <input type="text" name="description" /><br />
				published_date: <input type="date" name="published_date" /><br />
				publisher: <input type="text" name="publisher" /><br />
				updated_date:<input type="date" name="updated_date" /><br />
				<button>Add the record</button><br />
			</form>
		)

	}

	const callServer = async () => {
		axios.get("http://localhost:8082/books").then(function (res) {
			console.log(res.data.data.books_list);
			setBooks(res.data.data.books_list)
		}).catch(err => console.log(err));
	};

	return (
		<div>
			<h3>Edit</h3>

			<div>
				<table>
					<thead>
						<tr>

							<th>Title</th>
							<th>ISBN</th>
							<th>Author</th>
							<th>Description</th>
							<th>Published Date</th>
							<th>Publisher</th>
							<th>Updated Date</th>

						</tr>
					</thead>
					<tbody>
						{
							books.map(book => {
								const { _id, title, isbn, author, description, published_date, publisher, updated_date } = book;
								return (
									<tr key={_id}>
										<td>{title}</td>
										<td>{isbn}</td>
										<td>{author}</td>
										<td>{description}</td>
										<td>{published_date}</td>
										<td>{publisher}</td>
										<td>{updated_date}</td>
										<td>
											<button onClick={() => deleteUser(_id)}>Delete</button>
											<button onClick={(editFlag) => editUser(_id, title, isbn, author, description, published_date, publisher, updated_date, setEditFlag(true))}>Edit</button>
										</td>
									</tr>
								)
							})

						}
					</tbody>
				</table>
			</div>
		</div>
	)
}


export default ExpressServer;