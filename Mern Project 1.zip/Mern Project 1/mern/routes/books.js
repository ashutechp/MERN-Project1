var express = require("express");
var router = express.Router();
const booksController = require("../controllers/bookscontroller");

/* GET home Page */

//router.get("/", bookController.getBooks);
router.post("/", booksController.createBook);
router.get("/", booksController.getBooks);
router.delete("/:id",booksController.deleteBook)
router.put("/:id", booksController.editBook)

module.exports = router;