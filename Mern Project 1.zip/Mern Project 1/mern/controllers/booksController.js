const Books = require("../models/books");

exports.createBook = (request, response) => {
    const { title, isbn, author, description, published_date,publisher,updated_date } = request.body;
    let bookOb = new Books({ title, isbn, author, description, published_date,publisher,updated_date  });
    bookOb.save((err) => {
        if (err) {
            response.json(err);
        } else {
            response.json({ status: 1, data: { msg: "book created" } })
        }
    });
};

exports.getBooks = (request, response) => {
    Books.find((err, books_list) => {
        if (err) {
            response.json(err)
        } else {
            response.json({ status: 1, data: { books_list } });
        }
    });
};


exports.deleteBook = (request, response) => {
    Books.findByIdAndDelete(request.params.id, function (err) {
        if (err) {
            response.json(err);
        } else {
            response.send({
                status: 1,
                data: { msg: `books with id ${request.params.id} is deleted` },
            });
        }
    });
};


exports.editBook = (request, response) => {
    const updateob = request.body;
    Books.findByIdAndUpdate(request.params.id, updateob, function (err) {
        if (err) {
            response.json(err)
        } else {
            response.json({
                status: 1, data: { msg: `the Books with id ${request.params.id} is updated` },

            })
        }
    })
}
